# 혼합주의 · 화학물질 혼합 위험도 확인 사이트

두 화학물질의 이름을 입력하면 [PubChem](https://pubchem.ncbi.nlm.nih.gov/)에서 구조·분자식·GHS 유해성 정보를 실시간으로 불러오고, 자체 구축한 "알려진 위험 조합" 목록과 대조해 위험 여부를 보여주는 정적 웹사이트입니다. [ChemSpider](https://www.chemspider.com/)는 교차 확인용 외부 검색 링크로 함께 제공됩니다.

빌드 도구나 서버 없이 순수 HTML/CSS/JS로 동작하며, GitHub Pages에 그대로 올릴 수 있습니다.

## 파일 구성

```
index.html          메인 페이지
style.css           디자인
script.js           PubChem API 호출, GHS 코드 한글 변환, 위험 조합 판정 로직
data/reactions.json 알려진 위험 조합 데이터베이스 (직접 추가/수정 가능)
```

## GitHub Pages로 배포하기

1. GitHub에서 새 저장소를 만듭니다. (예: `chem-mix-checker`)
2. 이 폴더의 파일을 그대로 저장소에 올립니다.

   ```bash
   git init
   git add .
   git commit -m "첫 배포"
   git branch -M main
   git remote add origin https://github.com/<내-깃허브-아이디>/chem-mix-checker.git
   git push -u origin main
   ```

3. GitHub 저장소 페이지에서 **Settings → Pages**로 이동합니다.
4. **Source**를 `Deploy from a branch`로 설정하고, 브랜치는 `main`, 폴더는 `/ (root)`를 선택한 뒤 저장합니다.
5. 몇 분 뒤 `https://<내-깃허브-아이디>.github.io/chem-mix-checker/` 주소에서 사이트를 확인할 수 있습니다.

별도의 API 키나 백엔드 서버가 필요 없습니다 — PubChem PUG REST API는 브라우저에서 바로 호출할 수 있도록 CORS를 지원합니다.

## 위험 조합 데이터베이스 추가하기

`data/reactions.json`에 아래 형식으로 항목을 추가하면 됩니다.

```json
{
  "id": "고유id",
  "aliasesA": ["물질A 한글명", "물질A 영문명"],
  "aliasesB": ["물질B 한글명", "영문명"],
  "severity": "danger 또는 caution",
  "title": "짧은 제목",
  "summary": "한 줄 요약",
  "detail": "반응 원리와 생성물, 위험성에 대한 설명",
  "advice": "권장 대응 방법"
}
```

이름 매칭은 사용자가 입력한 문자열과 PubChem이 반환한 IUPAC명을 기준으로 이루어지므로, `aliasesA`/`aliasesB`에 자주 쓰이는 한글·영문 이름을 최대한 다양하게 추가해 두면 매칭률이 높아집니다.

## 알아두어야 할 한계

- **임의의 두 화학물질이 만났을 때 어떤 반응이 일어나는지 자동으로 예측하는 공개 데이터베이스는 존재하지 않습니다.** PubChem과 ChemSpider는 개별 화합물의 성질과 구조 정보를 제공할 뿐, "혼합 시 반응"을 계산해 주지는 않습니다. 이 사이트의 위험 판정은 `data/reactions.json`에 직접 등록해 둔, 이미 널리 알려진 위험한 조합(락스+암모니아 등)에 한정됩니다.
- **ChemSpider(Royal Society of Chemistry)의 공개 API는 발급받은 API 키가 필요**해서 정적 사이트에서 브라우저만으로 자동 호출하기 어렵습니다. 이 사이트에서는 대신 ChemSpider 검색 페이지로 바로 연결되는 링크만 제공합니다. 필요하다면 RSC에서 API 키를 발급받아 백엔드(서버리스 함수 등)를 통해 직접 연동할 수 있습니다.
- GHS 유해·위험문구(H-코드)의 한국어 번역은 참고용입니다. 실제 취급 전에는 제품의 정식 MSDS(물질안전보건자료)를 반드시 확인하세요.
